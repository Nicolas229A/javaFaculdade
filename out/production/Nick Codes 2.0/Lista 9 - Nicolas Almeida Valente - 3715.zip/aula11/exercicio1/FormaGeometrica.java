package aula11.exercicio1;

public interface FormaGeometrica {
    public double area( );
    public double comprimento( );
}
