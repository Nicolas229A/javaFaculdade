package aula12.exercicio2;

public abstract class OperacaoMatematica {
    public int x;
    public int y;
    public abstract int calcula();
}
