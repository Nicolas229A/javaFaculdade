package aula12.exercicio1;

public abstract class CartaoWeb {
    public String destinatario;
    public abstract void showMessage();
}
