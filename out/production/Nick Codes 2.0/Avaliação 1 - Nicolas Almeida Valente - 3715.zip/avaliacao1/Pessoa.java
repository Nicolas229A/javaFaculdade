package avaliacao1;

public class Pessoa {
    public String nome;
    public Documento documentos;
    public Pessoa proximaDaFila;
}
