package avaliacao1;

public class Documento {
    public String descricao;
    public int numero;
    public Documento abaixoDeste;
}
