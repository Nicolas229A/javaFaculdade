package aula17.lista15;

public interface Mediavel {
    public float media ();
}
